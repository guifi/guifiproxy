?package(guifi-proxy):needs="X11|text|vc|wm" section="Apps/see-menu-manual"\
  title="guifi-proxy" command="/usr/bin/guifi-proxy"
