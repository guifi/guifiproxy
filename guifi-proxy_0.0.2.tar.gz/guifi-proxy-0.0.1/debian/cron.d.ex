#
# Regular cron jobs for the guifi-proxy package
#
0 4	* * *	root	guifi-proxy_maintenance
